# Cricket-Football-Baseball Classification > 2026-05-25 8:59pm
https://universe.roboflow.com/cashata2014-gmail-com/cricket-football-baseball-classification-l58rf

Provided by a Roboflow user
License: Public Domain

## 251 images of playing cricket, football & baseball.

### [Original Dataset](https://www.kaggle.com/datasets/imbikramsaha/cricket-football-baseball)  from Kaggle - [Bikram Saha](https://www.kaggle.com/imbikramsaha)
This dataset contains 252 images of playing cricket, football, and baseball.
(1) `cricket` - `95` images
(2) `football` - `77` images
(3) `baseball` - `79` images

This is a dataset for image classification in sports. This model will help to identify if the sport or activity occurring in the image or video feed is, or most closely resembles, `cricket`, `football`, or `baseball`.

The raw image versions (`v1` or `v5`) of the dataset can be downloaded, or the [entire dataset can be cloned](https://blog.roboflow.com/use-open-source-computer-vision-datasets/), to your own project for image classification, or to label the figures in the images for object detection, instance or semantic segmentation, etc.